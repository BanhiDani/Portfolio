import random
import time

print("     ██        ██   ")    
time.sleep(0.2)
print("     ████      ████     ")
time.sleep(0.2)
print("    ██ ███ ██ ███ ███   ") 
time.sleep(0.2)
print("   ███ ██ █ ████ ████   ")
time.sleep(0.2)
print("  ██  -   ████  -  ██   ")
time.sleep(0.2)
print(" ██ ██████ █ ██   ████  ")
time.sleep(0.2)
print("███  ██ ████ ██ █ █████ ")
time.sleep(0.2)
print(" ██ █ █ █ █ █ █ █ █ ██ █")
time.sleep(0.2)
print("   █               ██   ")
time.sleep(0.2)
print("   ██ █ █ █ █ █ ██      ")
time.sleep(0.2)
print("    ████████████        ")
time.sleep(0.2)
print("     ██████████         ")


elet = 5

print('Válassz fegyvert!')
print('***************************************')
print('***************************************')
print('*******       1.  Kard          *******')
print('*******       2.  Íj            *******')
print('*******       3.  Varázspálca   *******')
print('***************************************')
print('***************************************')
szornyek = ["Sárkány", "Troll", "Boszorkány"]
szorny = random.choice(szornyek)
#print(a, szornyek[a]) #Teszteléshez
fegyver = int(input())


print("     ██        ██      ")
time.sleep(0.2)
print("     ████      ████    ")
time.sleep(0.2)
print("    ██ ███ ██ ███ ███  ")
time.sleep(0.2)
print("   ███ ██ █ ████ ████  ")
time.sleep(0.2)
print("  ██  ◎    ████  ◎  ██")
time.sleep(0.2)
print(" ███████   ████   ████ ")
time.sleep(0.2)
print("███  ██ ████ ██ █ █████")
time.sleep(0.2)
print(" ██ ██           ██ █  ")
time.sleep(0.2)
print(f" ██  {szorny}    ██  ")
time.sleep(0.2)
print(" ██               ██   ")
time.sleep(0.2)
print("  ██           ███     ")
time.sleep(0.2)
print("   ██         ████     ")
time.sleep(0.2)
print("    ███████████        ")
time.sleep(0.2)
print("     ██████████        ")



if fegyver == 1 or fegyver == 1:
    if szorny == "Troll":
        elet += 1
        print('Nyertél!')
    elif szorny == "Sárkány":
        elet -= 2
        print('Elvesztetted a csatát')       
    else:
        elet -= 2
        print('Elvesztetted a csatát')
elif fegyver == 2 or fegyver == 2 or fegyver == 2 or fegyver == 2:
    if szorny == "Boszorkány":
        elet += 1
        print('Győztél!')
    elif szorny == "Troll":
        elet -= 2
        print('Elvesztetted a csatát')
    else:
        elet -= 2
        print('Elvesztetted a csatát ')
elif fegyver == 3 or fegyver == 3 or fegyver == 3 or fegyver == 3:
    if szorny == "Sárkány":
        elet += 1
        print('Legyőzted!')
    elif szorny == "Troll":
        elet -= 2
        print('Elvesztetted a csatát')
    elif szorny == "Boszorkány":
        elet -= 2
        print('Elvesztetted a csatát')
else:
    print('Tudod fegyver nélkül elég nehéz lesz ;)')

print("Ennyi életed maradt még:", elet)

"""
if fegyver == 'Kard' or fegyver == 'kard':
    if a == 0:
        print('Legyőztél egy Troll-t')
    elif a == 1:
        print('Elvesztetted a csatát egy Sárkány ellen')
    else:
        print('Elvesztetted a csatát egy Boszorkány ellen')
elif fegyver == 'Íj' or fegyver == 'íj' or fegyver == 'ij' or fegyver == 'Ij':
    if a == 2:
        print('Legyőztél Boszorkányt')
    elif a == 0:
        print('Elvesztetted a csatát egy Troll ellen')
    else:
        print('Elvesztetted a csatát egy Sárkány ellen')
elif fegyver == 'Varázspálca' or fegyver == 'varázspálca' or fegyver == 'varazspalca' or fegyver == 'Varazspalca':
    if a == 1:
        print('Legyőztél egy Sárkányt')
    elif a == 0:
        print('Elvesztetted a csatát egy Troll ellen')
    elif a == 2:
        print('Elvesztetted a csatát egy Boszorkány ellen')
else:
    print('Tudod fegyver nélkül elég nehéz lesz')"""


