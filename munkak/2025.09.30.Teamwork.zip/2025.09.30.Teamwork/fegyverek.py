import random
import time
#elet = 3
"""szornyek = ["Ördög", "Mérges Hobó", "Bartos Cs István", "Alekosz", "Győzike"]
fegyverek = ["Használt tű", "Sör"]"""
#while elet == 0:
    szornyek = ["Sárkány", "Troll", "Boszorkány"]
    Fegyverek = ["Kard", "Íj", "Varázspálca"]

    szorny = random.choice(szornyek)

    print("     ██        ██   ")    
    time.sleep(0.2)
    print("     ████      ████     ")
    time.sleep(0.2)
    print("    ██ ███ ██ ███ ███   ") 
    time.sleep(0.2)
    print("   ███ ██ █ ████ ████   ")
    time.sleep(0.2)
    print("  ██  -   ████  -  ██   ")
    time.sleep(0.2)
    print(" ██ ██████ █ ██   ████  ")
    time.sleep(0.2)
    print("███  ██ ████ ██ █ █████ ")
    time.sleep(0.2)
    print(" ██ █ █ █ █ █ █ █ █ ██ █")
    time.sleep(0.2)
    print("   █               ██   ")
    time.sleep(0.2)
    print("   ██ █ █ █ █ █ ██      ")
    time.sleep(0.2)
    print("    ████████████        ")
    time.sleep(0.2)
    print("     ██████████         ")


    print()
    print(f"Egy", szorny, "ellen harcolsz")




    XP = 100
    Kard = 1
    Varázspálca = 2
    Íj = 3
    fegyver = int(input("Válaszd ki a fegyvered!"))

    fegyver = int(input("!Válaszd ki a fegyvered!:  Kard = 1 varázspálca = 2 Íj = 3 :   "))

    if szorny == "Troll" and fegyver == 1:
        print("Maga győzött!")
        print(XP + 50)
    elif szorny == "Boszorkány" and fegyver == 1:
        print("Maga vesztette ezt a küzdelmet")
        print(elet-1)
    elif szorny == "Sárkány" and fegyver == 1:
        print("Maga vesztette ezt a küzdelmet")
        print(elet-1)
    elif szorny == "Boszorkány" and fegyver == 3:
        print("Maga győzött!")
        print(XP + 50)
    elif szorny == "Troll" and fegyver == 3:
        print("Maga vesztette ezt a küzdelmet")
        print(elet-1)
    elif szorny == "Sárkány" and fegyver == 3:
        print("Maga vesztette ezt a küzdelmet")
        print(elet-1)
    elif szorny == "Sárkány" and fegyver == 2:
        print("Maga győzött!")
        print(XP + 50)
    elif szorny == "Boszorkány" and fegyver == 2:
        print("Maga vesztette ezt a küzdelmet")
        print(elet-1)
    elif szorny == "Troll" and fegyver == 2:
        print("Maga vesztette ezt a küzdelmet")
        print(elet-1)

    print("Még ennyi életed van:", elet )