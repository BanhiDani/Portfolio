import bejelentkezes
import sorozat
import rendeles

"""x = sorozat.VeletlenSzam()
sorozat.kiiras1(x)
y = sorozat.kisebb(x)
sorozat.konzolba_ir(y)
sorozat.fajlba_ir(y)"""

lista = rendeles.fajlbeolvasas()
a = rendeles.rendeles_tetel(lista)
b = rendeles.BG01tipus(lista)
c = rendeles.legnagyobb(lista)
rendeles.kiir(a, b, c)

