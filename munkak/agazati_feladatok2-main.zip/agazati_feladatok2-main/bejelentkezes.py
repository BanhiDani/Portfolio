import random


""" 1. Feladat """

def elso_feladat():
    print("I/A,B:")
    email1 = str(input("Email cím: "))
    email2 = str(input("Email cím mégegyszer: "))
    jelszo = str(input("Jelszó: "))
    print("I/C:")
    if email1 == email2 and jelszo != "":
        print(f"Sikeres bejelentkezés {email1}!")
    elif jelszo == "":
        print("Sikertelen bejelentkezés (üres jelszó).")
    else:
        print("Sikertelen bejelentkezés (email címek nem egyeznek).")

