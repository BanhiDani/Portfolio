from Adat import Adat

""" 3. Feladat """

def fajlbeolvasas():
    lista = []
    sorok = []
    sor = []
    i = 0
    with open("rendeles.txt", "r", encoding="UTF-8") as f:
        f.readline()
        sorok = f.readlines()
        f.close()
        while i < len(sorok):
            sor = sorok[i].strip().split("-")
            rendeles = Adat(sor[0], sor[1], int(sor[2]))
            lista.append(rendeles)
            i += 1
        
    return lista
    
def rendeles_tetel(lista):
    x = len(lista)
    return x

def BG01tipus(lista):
    i = 0
    szamlalo = 0
    while i < len(lista):
        if lista[i].cikkSzam == "BG01":
            szamlalo += 1
        i += 1
    return szamlalo

def legnagyobb(lista):
    i = 0
    x = 0
    tarolo = 0
    while i < len(lista):
        if lista[i].menny > x:
            tarolo = lista[i].rendSzam
            x = lista[i].menny
        i += 1
    return tarolo

def kiir(x, szamlalo, tarolo):
    print("III/A,B:")
    print(f"rendelési tételek száma: {x}.")
    print("III/C:")
    print(f"A 'BG01' típushoz tartozó megrendelések összes mennyisége: {szamlalo}.")
    print("III/D:")
    print(f"A legnagyobb mennyiségű rendelési tételhez tartozó rendelési szám: {tarolo}.")
    
            

        
        