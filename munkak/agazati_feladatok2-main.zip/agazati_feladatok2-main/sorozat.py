import random

""" 2. Feladat """

def VeletlenSzam():
    lista = []
    for x in range(1, 6, 1):
        a = random.randint(10,20)
        lista.append(a)
    return lista
def kiiras1(lista):
    print("II/A,B,C:")
    i = 0
    while i < len(lista):
        if i == len(lista)-1:
            print(lista[i], end="" "\n")
        else:
            print(lista[i], end="-")
        i += 1
def kisebb(lista):
    szam = int(0)
    akt = 0
    i = 0
    while i < len(lista):
        if lista[i] < akt:
            szam += 1
        akt = lista[i]
        i += 1
    return szam

def konzolba_ir(szam):
    print("II/D,E:")
    print(f"Kisebb számok száma: {szam}.")

def fajlba_ir(szam):
    with open("vegeredmeny.txt", "w", encoding="UTF-8") as f:
        f.write("II/F: \n")
        f.write(f"Kisebb számok száma: {szam}.")
        f.close