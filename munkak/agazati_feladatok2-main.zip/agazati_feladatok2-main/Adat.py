class Adat:

    def __init__(self, rendSzam, cikkSzam, menny:int):
        self.rendSzam = int(rendSzam)
        self.cikkSzam = cikkSzam
        self.menny = int(menny)
    def __str__(self):
        txt = f"{self.rendSzam}, {self.cikkSzam}, {self.menny}"
        return txt