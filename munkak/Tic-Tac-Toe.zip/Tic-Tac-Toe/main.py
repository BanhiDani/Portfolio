import eljarasok

jatek = [
    [".",".","."],
    [".",".","."],
    [".",".","."]
]

cv = 0
eljarasok.kiir(jatek)
while cv == 0:
    eljarasok.felhasznalo(jatek)
    cv = eljarasok.vegevan_e(jatek)
    if cv == 0:
        eljarasok.gep_lep(jatek)
        cv = eljarasok.vegevan_e(jatek)
        if cv == 0:
            eljarasok.kiir(jatek)
eljarasok.kiir(jatek)
eljarasok.eredmeny(cv)



