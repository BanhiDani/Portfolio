import random


def kiir(jatek):
    print("\n    1   2   3")
    print(f"A   {jatek[0][0]} | {jatek[0][1]} | {jatek[0][2]}")
    print("   ---+---+---")
    print(f"B   {jatek[1][0]} | {jatek[1][1]} | {jatek[1][2]}")
    print("   ---+---+---")
    print(f"C   {jatek[2][0]} | {jatek[2][1]} | {jatek[2][2]}\n")
    return jatek

def gep_lep(jatek):
    sor = random.randint(0, 2)
    oszlop = random.randint(0, 2)
    while not (jatek[sor][oszlop] == "."):
        sor = random.randint(0, 2)
        oszlop = random.randint(0, 2)
    jatek[sor][oszlop] = "O"
    return jatek

def felhasznalo(jatek):
    sor = str(input("a, b, c? "))
    oszlop = int(input("1, 2, 3? "))
    while ((sor != "a") and (sor != "b") and (sor != "c")) or ((oszlop != 1) and (oszlop != 2) and (oszlop != 3)):
        print("Ilyen hely nem létezik!")
        sor = str(input("a, b, c? "))
        oszlop = int(input("1, 2, 3? "))
    if sor == "a":
        sor = 0
    elif sor == "b":
        sor = 1
    elif sor == "c":
        sor = 2
    oszlop += -1
    while not(jatek[sor][oszlop] == "."):
        print("Ez a hely már foglalt!")
        sor = str(input("a, b, c? "))
        oszlop = int(input("1, 2, 3? "))
        if sor == "a":
            sor = 0
        elif sor == "b":
            sor = 1
        elif sor == "c":
            sor = 2
            oszlop += -1
    jatek[sor][oszlop] = "X"
    return jatek

def vegevan_e(jatek):
    vege = 0
    x = 0
    y = 0

    """ Felhasználó nyer """
    while x < len(jatek):
        y = 0
        teljes_sor = True
        while y < len(jatek) and teljes_sor == True:
            if jatek[x][y] != "X":
                teljes_sor = False
            y += 1
        if teljes_sor == True:
            vege = 1
        x += 1
    x = 0
    y = 0
    while y < len(jatek):
        x = 0
        teljes_oszlop = True
        while x < len(jatek) and teljes_oszlop == True:
            if jatek[x][y] != "X":
                teljes_oszlop = False
            x +=1
        if teljes_oszlop == True:
            vege = 1
        y += 1
    x = 0
    y = 0
    teljes_atlo1 = True
    while x < len(jatek) and teljes_atlo1 == True:
        if jatek[x][x] != "X":
            teljes_atlo1 = False
        x += 1
    if teljes_atlo1 == True:
        vege = 1
    x = 0
    teljes_atlo2 = True
    while x < len(jatek) and teljes_atlo2 == True:
        if jatek[x][len(jatek) - 1 - x] != "X":
            teljes_atlo2 = False
        x += 1
    if teljes_atlo2 == True:
        vege = 1

    """ Gép nyer """

    x = 0
    y = 0
    while x < len(jatek):
        y = 0
        teljes_sor = True
        while y < len(jatek) and teljes_sor == True:
            if jatek[x][y] != "O":
                teljes_sor = False
            y += 1
        if teljes_sor == True:
            vege = 2
        x += 1
    x = 0
    y = 0
    while y < len(jatek):
        x = 0
        teljes_oszlop = True
        while x < len(jatek) and teljes_oszlop == True:
            if jatek[x][y] != "O":
                teljes_oszlop = False
            x += 1
        if teljes_oszlop == True:
            vege = 2
        y += 1
    x = 0
    teljes_atlo1 = True
    while x < len(jatek) and teljes_atlo1 == True:
        if jatek[x][x] != "O":
            teljes_atlo1 = False
        x += 1
    if teljes_atlo1 == True:
        vege = 2
    x = 0
    teljes_atlo2 = True
    while x < len(jatek) and teljes_atlo2 == True:
        if jatek[x][len(jatek) - 1 - x] != "O":
            teljes_atlo2 = False
        x += 1
    if teljes_atlo2 == True:
        vege = 2

    """ Döntetlen """
    if vege == 0:
        x = 0
        van_ures = False
        while x < len(jatek) and van_ures == False:
            y = 0
            while y < len(jatek) and van_ures == False:
                if jatek[x][y] == ".":
                    van_ures = True
                y += 1
            x += 1
        if van_ures == False:
            vege = 3
        
    return vege

def eredmeny(vege):
    if vege == 1:
        print("Gratulálok Nyertél!")
    elif vege == 2:
        print("Vesztettél!")
    else:
        print("Döntetlen")